import random
from random import shuffle

def func1(s):
    num = [0,1]
    return random.choice(num)
